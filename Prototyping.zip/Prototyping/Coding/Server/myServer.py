from flask import Flask, Response, render_template, request
import json
from subprocess import Popen, PIPE
import os
from tempfile import mkdtemp
from werkzeug import secure_filename
import tweepy
from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.streaming import StreamListener
import random
from datetime import datetime

#! /usr/local/bin/python  -*- coding: UTF-8 -*-


app = Flask(__name__)


@app.route("/")
def index():


    consumer_key = 'yL0iWUkIh8X2UddhU24sJas53'
    consumer_secret = 'vsojVKCKFIuyhyP9LcL1aCRBZHHoy0EtUeN6B9bOWaRJA5J5NL'
    access_token = '254286536-LRLyCSoU8JI0KBV9pVZwJTQJSfr5o0ZQWaplPFIP'
    access_token_secret = 'dLriHb9z9Fi7WKN1xRYwHfoechCcvxJ0isGZLe6oTr0o7'

    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    api = tweepy.API(auth)


    search_text = "#events"
    search_number = 900
    search_result = api.search(search_text, rpp = search_number)



    text = "Test -==== Bug 2 ====-"



    for i in search_result:
        tweet = " ====> Tweet generated in " + str(datetime.now()) + "<====---------###--------" + i.text + "---------###--------"
        #print search_result
        print tweet
        return json.dumps(tweet)


    
    # jsonify will do for us all the work, returning the
    # previous data structure in JSON
    text = "Test -==== Bug 1 ====-"
    return json.dumps(text)




if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080,  debug=True)




